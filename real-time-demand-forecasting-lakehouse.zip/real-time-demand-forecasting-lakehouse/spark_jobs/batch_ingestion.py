import json
import pathlib
from datetime import datetime

import pandas as pd
import yaml

CONFIG_PATH = pathlib.Path(__file__).resolve().parents[1] / "config" / "streaming_config.yml"
OUTPUT_DIR = pathlib.Path(__file__).resolve().parents[1] / "spark_jobs" / "output"
OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

def load_config():
    with open(CONFIG_PATH, "r") as f:
        return yaml.safe_load(f)

def load_events_to_bronze(events_dir: pathlib.Path) -> pd.DataFrame:
    files = sorted(events_dir.glob("orders_*.jsonl"))
    records = []
    for fp in files:
        with open(fp, "r") as f:
            for line in f:
                try:
                    records.append(json.loads(line))
                except json.JSONDecodeError:
                    continue
    df = pd.DataFrame(records)
    return df

def transform_to_silver(df: pd.DataFrame) -> pd.DataFrame:
    if df.empty:
        return df
    df["order_timestamp"] = pd.to_datetime(df["order_timestamp"])
    df["total_amount"] = df["quantity"] * df["price"]
    return df

def write_parquet(df: pd.DataFrame, name: str):
    if df.empty:
        print("No data to write.")
        return
    out_path = OUTPUT_DIR / f"{name}.parquet"
    df.to_parquet(out_path, index=False)
    print(f"Wrote {len(df)} records to {out_path}")

def main():
    config = load_config()
    events_dir = pathlib.Path(config["streaming"]["events_dir"])
    df_bronze = load_events_to_bronze(events_dir)
    print(f"Loaded {len(df_bronze)} raw events from {events_dir}")
    df_silver = transform_to_silver(df_bronze)
    write_parquet(df_silver, "orders_silver")

if __name__ == "__main__":
    main()
