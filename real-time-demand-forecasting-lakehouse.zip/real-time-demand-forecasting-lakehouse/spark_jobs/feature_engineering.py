import pathlib
import pandas as pd

INPUT_PATH = pathlib.Path(__file__).resolve().parents[1] / "spark_jobs" / "output" / "orders_silver.parquet"
FEATURES_OUTPUT = pathlib.Path(__file__).resolve().parents[1] / "ml" / "data"
FEATURES_OUTPUT.mkdir(parents=True, exist_ok=True)

def build_daily_features(df: pd.DataFrame) -> pd.DataFrame:
    df["order_date"] = df["order_timestamp"].dt.date
    daily = (
        df.groupby(["order_date", "product_id"])
        .agg(
            total_quantity=("quantity", "sum"),
            total_revenue=("total_amount", "sum")
        )
        .reset_index()
    )
    daily = daily.sort_values(["product_id", "order_date"])
    return daily

def main():
    if not INPUT_PATH.exists():
        print(f"Input file not found: {INPUT_PATH}")
        return
    df = pd.read_parquet(INPUT_PATH)
    df_feat = build_daily_features(df)
    out_csv = FEATURES_OUTPUT / "daily_product_sales.csv"
    df_feat.to_csv(out_csv, index=False)
    print(f"Wrote features to {out_csv}")

if __name__ == "__main__":
    main()
